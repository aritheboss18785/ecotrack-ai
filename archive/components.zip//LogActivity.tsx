import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Plus, Car, Utensils, Zap, ShoppingBag, Trash2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Activity {
  id: string;
  category: string;
  amount: number;
  unit: string;
  co2Impact: number;
  date: string;
  time: string;
}

interface LogActivityProps {
  onAddActivity: (activity: Omit<Activity, 'id'>) => void;
}

export function LogActivity({ onAddActivity }: LogActivityProps) {
  const [category, setCategory] = useState('');
  const [amount, setAmount] = useState('');
  const [unit, setUnit] = useState('');

  const categories = [
    { id: 'transport', label: 'Transport', icon: Car, units: ['miles', 'km', 'gallons'] },
    { id: 'food', label: 'Food', icon: Utensils, units: ['servings', 'lbs', 'kg'] },
    { id: 'energy', label: 'Energy', icon: Zap, units: ['kWh', 'therms', 'hours'] },
    { id: 'shopping', label: 'Shopping', icon: ShoppingBag, units: ['items', 'dollars', 'euros'] },
    { id: 'waste', label: 'Waste', icon: Trash2, units: ['lbs', 'kg', 'bags'] },
  ];

  const selectedCategory = categories.find(cat => cat.id === category);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!category || !amount || !unit) {
      toast.error('Please fill in all fields');
      return;
    }

    // Calculate rough CO2 emission based on category and amount
    const calculateCO2 = () => {
      const value = parseFloat(amount);
      switch (category) {
        case 'transport':
          return unit === 'miles' ? value * 0.4 : value * 0.25; // kg CO2 per mile/km
        case 'food':
          return value * 2.5; // kg CO2 per serving/lb
        case 'energy':
          return value * 0.5; // kg CO2 per kWh
        case 'shopping':
          return value * 0.1; // kg CO2 per item/dollar
        case 'waste':
          return value * 0.3; // kg CO2 per lb/kg
        default:
          return 0;
      }
    };

    const co2Impact = calculateCO2();
    
    // Add activity to the global state
    const now = new Date();
    onAddActivity({
      category,
      amount: parseFloat(amount),
      unit,
      co2Impact,
      date: now.toISOString().split('T')[0],
      time: now.toTimeString().slice(0, 5)
    });
    
    toast.success(
      `Activity logged! Added ${co2Impact.toFixed(1)} kg CO₂e to your footprint.`
    );

    // Reset form
    setCategory('');
    setAmount('');
    setUnit('');
  };

  return (
    <div className="p-4 pb-20 bg-[#f8fffe] min-h-screen">
      {/* Header */}
      <div className="text-center pt-4 mb-8">
        <h1 className="text-3xl text-green-600 mb-2">Log Activity</h1>
        <p className="text-gray-600">Add a new carbon footprint activity</p>
      </div>

      {/* Category Selection */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        {categories.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => {
              setCategory(id);
              setUnit(''); // Reset unit when category changes
            }}
            className={`p-4 rounded-lg border-2 transition-all duration-200 ${
              category === id
                ? 'border-green-500 bg-green-50 text-green-700'
                : 'border-gray-200 bg-white text-gray-600 hover:border-green-300'
            }`}
          >
            <Icon size={32} className="mx-auto mb-2" />
            <div className="text-sm">{label}</div>
          </button>
        ))}
      </div>

      {/* Log Form */}
      <Card className="bg-white border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-700">
            <Plus size={20} />
            Log a New Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Category Display */}
            {selectedCategory && (
              <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 text-green-700">
                  <selectedCategory.icon size={20} />
                  <span>Selected: {selectedCategory.label}</span>
                </div>
              </div>
            )}

            {/* Amount Input */}
            <div className="space-y-2">
              <Label htmlFor="amount" className="text-gray-700">Amount</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount (e.g., 10)"
                className="text-lg"
                step="0.1"
                min="0"
              />
            </div>

            {/* Unit Selection */}
            <div className="space-y-2">
              <Label htmlFor="unit" className="text-gray-700">Unit</Label>
              <Select value={unit} onValueChange={setUnit} disabled={!category}>
                <SelectTrigger className="text-lg">
                  <SelectValue placeholder="Select unit" />
                </SelectTrigger>
                <SelectContent>
                  {selectedCategory?.units.map((unitOption) => (
                    <SelectItem key={unitOption} value={unitOption}>
                      {unitOption}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Submit Button */}
            <Button 
              type="submit" 
              className="w-full bg-green-500 hover:bg-green-600 text-white py-3 text-lg rounded-lg shadow-lg"
              disabled={!category || !amount || !unit}
            >
              <Plus size={20} className="mr-2" />
              Log Activity
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Quick Tips */}
      <Card className="mt-6 bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <h3 className="text-blue-700 mb-2">💡 Quick Tips</h3>
          <ul className="text-sm text-blue-600 space-y-1">
            <li>• Be as accurate as possible for better tracking</li>
            <li>• Log activities throughout the day</li>
            <li>• Small changes add up to big impacts</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}