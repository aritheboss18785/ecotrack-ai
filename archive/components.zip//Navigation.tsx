import React from 'react';
import { Home, Plus, TrendingUp } from 'lucide-react';

interface NavigationProps {
  activeTab: 'dashboard' | 'log' | 'progress';
  onTabChange: (tab: 'dashboard' | 'log' | 'progress') => void;
}

export function Navigation({ activeTab, onTabChange }: NavigationProps) {
  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'log', label: 'Log Activity', icon: Plus },
    { id: 'progress', label: 'Progress', icon: TrendingUp },
  ] as const;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
      <div className="flex justify-around items-center max-w-md mx-auto">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => onTabChange(id)}
            className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all duration-200 ${
              activeTab === id
                ? 'text-green-500 bg-green-50'
                : 'text-gray-500 hover:text-green-400 hover:bg-gray-50'
            }`}
          >
            <Icon size={24} />
            <span className="text-xs">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}